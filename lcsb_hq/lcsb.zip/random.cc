#include "headers.h"


// -----------------------------------------------------------------------------
uint32_t uniform32(					// unsigned r.v. from Uniform(min, max)
	uint32_t min,						// min value
	uint32_t max)						// max value
{
	uint32_t r = 0;
	if (RAND_MAX >= max - min) {
		r = min + (uint32_t) ((max - min + 1.0f) * rand() / (RAND_MAX + 1.0f));
	}
	else {
		r = min + (uint32_t) ((max - min + 1.0f) * ((uint64_t) rand() * 
			((uint64_t) RAND_MAX + 1) + (uint64_t) rand()) / 
			((uint64_t) RAND_MAX * ((uint64_t) RAND_MAX + 1) + 
			(uint64_t) RAND_MAX + 1.0));
	}
	assert(r >= min && r <= max);

	return r; 
}

// -----------------------------------------------------------------------------
float uniform(						// r.v. from Uniform(min, max)
	float min,							// min value
	float max)							// max value
{
	int   num  = rand();
	float base = (float) RAND_MAX - 1.0F;
	float frac = ((float) num) / base;

	return (max - min) * frac + min;
}

// -----------------------------------------------------------------------------
//	Given a mean and a standard deviation, gaussian generates a normally 
//		distributed random number.
//
//	Algorithm:  Polar Method, p.104, Knuth, vol. 2
// -----------------------------------------------------------------------------
float gaussian(						// r.v. from Gaussian(mean, sigma)
	float mean,							// mean value
	float sigma)						// std value
{
	float v1 = -1.0f;
    float v2 = -1.0f;
	float s  = -1.0f;
	float x  = -1.0f;

	do {
		v1 = 2.0F * uniform(0.0F, 1.0F) - 1.0F;
		v2 = 2.0F * uniform(0.0F, 1.0F) - 1.0F;
		s = v1 * v1 + v2 * v2;
	} while (s >= 1.0F);
	x = v1 * sqrt (-2.0F * log (s) / s);

	x = x * sigma + mean; 			// x is distributed from N(0, 1)
	return x;
}

// -----------------------------------------------------------------------------
float normal_pdf(					// pdf of Guassian(mean, std)
	float x,							// variable
	float u,							// mean
	float sigma)						// standard error
{
	float ret = exp(-(x - u) * (x - u) / (2.0f * sigma * sigma));
	ret /= sigma * sqrt(2.0f * PI);
	return ret;
}

// -----------------------------------------------------------------------------
float normal_cdf(					// cdf of N(0, 1) in range (-inf, x]
	float _x,							// integral border
	float _step)						// step increment
{
	float ret = 0.0;
	for (float i = -10.0; i < _x; i += _step) {
		ret += _step * normal_pdf(i, 0.0f, 1.0f);
	}
	return ret;
}

// -----------------------------------------------------------------------------
float new_cdf(						// cdf of N(0, 1) in range [-x, x]
	float x,							// integral border
	float step)							// step increment
{
	float result = 0.0f;
	for (float i = -x; i <= x; i += step) {
		result += step * normal_pdf(i, 0.0f, 1.0f);
	}
	return result;
}