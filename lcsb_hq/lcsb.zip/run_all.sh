#!/bin/bash

./run_mnist.sh 
./run_trevi.sh
./run_sift.sh
./run_gist.sh 

# ./run_movielens.sh
# ./run_netflix.sh
# ./run_yahoo.sh 
